package com.cellcom.cellcompopulars

class Prefs {

    companion object {
       var pagesSize: Int? = null
    }
}