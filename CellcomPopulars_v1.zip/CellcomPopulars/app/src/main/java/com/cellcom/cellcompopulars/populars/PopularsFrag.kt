package com.cellcom.cellcompopulars.populars

import PaginationScrollListener
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cellcom.cellcompopulars.OnSwipeTouchListener
import com.cellcom.cellcompopulars.Prefs
import com.cellcom.cellcompopulars.R


class PopularsFrag : Fragment() {
    var layoutManager: LinearLayoutManager? = null
    var isLastPage: Boolean = false
    var isFirstPage: Boolean = false
    var isLoading: Boolean = false
    var popularsViewModel: PopularsViewModel? = null

    var page:Int = 1

    companion object {
        fun newInstance() = PopularsFrag()
    }

    private lateinit var viewModel: PopularsViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.populars_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(PopularsViewModel::class.java)
        // TODO: Use the ViewModel
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerview = view.findViewById<RecyclerView>(R.id.recycler_view)

        layoutManager = LinearLayoutManager(view.context)
        recyclerview.layoutManager = layoutManager


        popularsViewModel = PopularsViewModel()
        popularsViewModel!!.getPopulars(recyclerview)

//        recyclerview?.addOnScrollListener(object : PaginationScrollListener(layoutManager!!) {
//            override fun isLastPage(): Boolean {
//                return isLastPage
//            }
//
//            override fun isFirstPage(): Boolean {
//                return isFirstPage
//            }
//
//            override fun isLoading(): Boolean {
//                return isLoading
//            }
//
//            override fun loadMoreItems() {
//                isLoading = true
//                //you have to call loadmore items to get more data
//                getMoreItems(recyclerview)
//            }
//
//            override fun loadLessItems() {
//                getLessItems(recyclerview)
//            }
//        })

        recyclerview.setOnTouchListener(object : OnSwipeTouchListener(context) {
            override fun onSwipeLeft() {
//                super.onSwipeLeft()
                getMoreItems(recyclerview)
            }

            override fun onSwipeRight() {
//                super.onSwipeRight()
                getLessItems(recyclerview)
            }
        })

    }

    fun getMoreItems(recyclerview: RecyclerView) {
        //after fetching your data assuming you have fetched list in your
        // recyclerview adapter assuming your recyclerview adapter is
        //rvAdapter
//        after getting your data you have to assign false to isLoading
        isLoading = false
        if(page < Prefs.pagesSize!!) {
            page++
            popularsViewModel?.getPopulars(recyclerview, page)
        }

    }

    fun getLessItems(recyclerview: RecyclerView) {
        isLoading = false
        if(page > 1) {
            page--
            popularsViewModel?.getPopulars(recyclerview, page, true)
        }

    }
}