package com.cellcom.cellcompopulars.populars

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.recyclerview.widget.RecyclerView
import com.cellcom.cellcompopulars.MainActivity
import com.cellcom.cellcompopulars.Prefs
import com.cellcom.cellcompopulars.api.APIClient
import com.cellcom.cellcompopulars.populars.recycleview.PopularsAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PopularsViewModel : ViewModel() {
    var pagesSize: Int? = null


     fun getPopulars(recyclerview: RecyclerView, page: Int = 1, isScrollingUp: Boolean = false) {
        var api = APIClient.instance?.getMyApi()

         System.out.println("page = $page")
         System.out.println("pagesSize = ${Prefs.pagesSize}")

         if(page < 1 || (Prefs.pagesSize != null && page > Prefs.pagesSize!!)) {
             return
         }

        api?.getPopularMoviesByPage(page)?.enqueue(object : Callback<PopularsResult> {
            override fun onResponse(call: Call<PopularsResult>, response: Response<PopularsResult>) {
                Log.i(MainActivity::class.simpleName, "on Success!!!!")
                Log.i(MainActivity::class.simpleName, "response = ${response.body()}")
                Prefs.pagesSize = response.body()?.total_pages
                var populars = response.body()?.results

        val adapter = populars?.let { PopularsAdapter(it) }
        recyclerview.adapter = adapter
//                if(isScrollingUp) {
//                    System.out.println("isScrollingUp = true")
//                    val visibleItemCount = recyclerview.layoutManager?.childCount
//                    recyclerview.layoutManager?.scrollToPosition(populars!!.size - visibleItemCount!!)
//                }

            }

            override fun onFailure(call: Call<PopularsResult>, t: Throwable) {
                Log.i(MainActivity::class.simpleName, "on FAILURE!!!!")
            }

        })

    }
}